# Mboka Flow — Site prototype

## Fichiers
- index.html : structure du site
- styles.css : design responsive
- script.js : interactions de la démo

## Utilisation
1. Décompressez le dossier.
2. Ouvrez `index.html` dans Chrome, Edge ou Firefox.
3. Pour une mise en ligne, envoyez les trois fichiers sur votre hébergement.

## Important
La carte et les données de trafic de cette version sont fictives. Pour la version réelle, il faudra connecter :
- une API cartographique (par exemple OpenStreetMap/Mapbox/Google Maps selon le choix du projet),
- un backend,
- une base de données,
- les données GPS/traffic autorisées,
- les signalements utilisateurs,
- et, si possible, des données institutionnelles.

Le formulaire de contact utilise `mailto:` et ouvre le logiciel email de l'utilisateur. Pour un formulaire professionnel, connectez ensuite un backend ou un service de formulaire.

Contact : dabodanga2019@gmail.com
Slogan : Kinshasa sans embouteillage, c'est possible.


## Modules fonctionnels ajoutés
1. Carte interactive : rouge/orange/vert.
2. Navigation et itinéraires.
3. Alertes communautaires.
4. Informations officielles.
5. Base de données des points noirs.
6. Données temps réel : GPS, caméras, capteurs et APIs selon autorisations.
